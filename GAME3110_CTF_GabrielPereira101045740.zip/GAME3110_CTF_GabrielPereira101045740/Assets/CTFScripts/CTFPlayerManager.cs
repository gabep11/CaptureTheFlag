﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CTFPlayerManager : NetworkBehaviour {

    GameObject spawnManager;
    public Transform flagPlaceHolder;

    [SyncVar]
    private bool m_hasFlag = false;

    [SyncVar]
    private float score = 0.0f;

    // Use this for initialization
    void Start () {
		
	}

    public override void OnStartLocalPlayer()
    {
        
    }

    // Update is called once per frame
    void Update () {
		if (m_hasFlag)
        {
            spawnManager = GameObject.Find("SpawnManager");
            score += Time.deltaTime;
            spawnManager.GetComponent<CTFSpawnManager>().CmdUpdateScores();
        }
	}

    public bool HasFlag()
    {
        return m_hasFlag;
    }

    [Command]
    public void CmdPickUpFlag()
    {
        m_hasFlag = true;
    }

    [Command]
    public void CmdDropFlag()
    {
        m_hasFlag = false;
    }

    public float GetScore()
    {
        return score;
    }
}
