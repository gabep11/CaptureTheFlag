﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CTFSpawnManager : NetworkBehaviour {

    [SyncVar]
    public float RoundTimer;
    public GameObject flagPrefab = null;

    public Text FirstPlaceText = null;
    public Text SecondPlaceText = null;
    public Text TimerText = null;
    public GameObject HUDPanel = null;
    public GameObject GameOverPanel = null;
    public Text GameOverText = null;

    GameObject[] flagRespawns;
    GameObject[] players;

    [SyncVar]
    private string currWinnerName = null;
    private bool winnerNull = true;

    // Use this for initialization
    void Start ()
    {
        if (isServer)
        {
            flagRespawns = GameObject.FindGameObjectsWithTag("FlagSpawn");
            CmdSpawnFlag();
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (isServer)
        {
            if (RoundTimer <= 0.0f)
            {
                RpcExecGameOver(winnerNull, currWinnerName);
            }
            else
            {
                RoundTimer -= Time.deltaTime;
            }
        }
        
        TimerText.text = "Time Remaining: " + (int)RoundTimer + "s";
    }

    [ClientRpc]
    void RpcExecGameOver(bool tie, string winner)
    {
        HUDPanel.SetActive(false);
        GameOverPanel.SetActive(true);

        players = GameObject.FindGameObjectsWithTag("Player");
        foreach (GameObject player in players)
        {
            player.GetComponent<CTFPlayerController>().enabled = false;
        }

        if (tie)
        {
            GameOverText.text = "Game Over!\nTie Game!\nPress ESC To Play Again!";
        }
        else
        {
            GameOverText.text = "Game Over!\n" + winner + " Wins!\nPress ESC To Play Again!";
        }
    }

    [Command]
    public void CmdSpawnFlag()
    {
        if (flagPrefab)
        {
            Transform spwnPos = GetRandomFlagSpawnPos();
            var flag = (GameObject)Instantiate(flagPrefab, spwnPos.position, spwnPos.rotation);
            NetworkServer.Spawn(flag);
        }
    }

    private Transform GetRandomFlagSpawnPos()
    {
        int index = UnityEngine.Random.Range(0, flagRespawns.Length);
        return flagRespawns[index].transform;
    }

    [Command]
    public void CmdDestroyFlag()
    {
        RpcDestroyFlag();
    }

    [ClientRpc]
    public void RpcDestroyFlag()
    {
        GameObject[] flags = GameObject.FindGameObjectsWithTag("Flag");
        foreach (GameObject flag in flags)
        {
            Destroy(flag);
        }
        CmdSpawnFlag();
    }

    [Command]
    public void CmdUpdateScores()
    {
        RpcUpdateScores();
    }

    [ClientRpc]
    public void RpcUpdateScores()
    {
        players = GameObject.FindGameObjectsWithTag("Player");
        //Debug.Log(players.Length);

        Array.Sort(players, delegate (GameObject x, GameObject y) { return y.GetComponent<CTFPlayerManager>().GetScore().CompareTo(x.GetComponent<CTFPlayerManager>().GetScore()); } );

        currWinnerName = players[0].GetComponent<CTFSetupLocalPlayer>().GetPlayerName();
        winnerNull = false;
        string firstText = "1st | " + players[0].GetComponent<CTFSetupLocalPlayer>().GetPlayerName() + ": " + (int)players[0].GetComponent<CTFPlayerManager>().GetScore();
        string secondText = "2nd | " + players[1].GetComponent<CTFSetupLocalPlayer>().GetPlayerName() + ": " + (int)players[1].GetComponent<CTFPlayerManager>().GetScore();

        FirstPlaceText.text = firstText;
        SecondPlaceText.text = secondText;
        //Debug.Log("Called");
        //var firstPlaceText = Camera.main.transform.Find("FirstPlaceScore").gameObject;
        //var secondPlaceText = Camera.main.transform.Find("SecondPlaceScore").gameObject;
        //firstPlaceText.GetComponent<Text>().text = firstText;
        //secondPlaceText.GetComponent<Text>().text = secondText;

        //foreach (Transform child in Camera.main.transform)
        //{
        //    if (child.name == "FirstPlaceScore") { FirstPlaceText = child.gameObject.GetComponent<Text>(); }
        //    if (child.name == "SecondPlaceScore") { SecondPlaceText = child.gameObject.GetComponent<Text>(); }
        //}
    }

}
