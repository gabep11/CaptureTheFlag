﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CTFSetupLocalPlayer : NetworkBehaviour {

    [SerializeField]
    GameObject playerTag;

    [SyncVar]
    public string pName = "player";

    [SyncVar]
    public Color playerColor = Color.white;

	// Use this for initialization
	void Start ()
    {
        playerTag.GetComponent<TextMesh>().text = pName;
        GetComponent<MeshRenderer>().material.color = playerColor;
    }

    public override void OnStartLocalPlayer()
    {
        playerTag.SetActive(false);
        GetComponent<CTFPlayerController>().enabled = true;
        CTFSmoothCameraFollow.target = this.transform;
    }
	
	// Update is called once per frame
	void Update ()
    {
        //this.transform.rotation = Quaternion.Euler(0, this.transform.rotation.y, 0);

        //Quaternion originalRot = transform.rotation;
        //this.transform.rotation = originalRot * Quaternion.AngleAxis(0, Vector3.forward);
        //originalRot = transform.rotation;
        //this.transform.rotation = originalRot * Quaternion.AngleAxis(0, Vector3.right);
        //Debug.Log(transform.rotation.x);
    }

    public string GetPlayerName()
    {
        return pName;
    }

    [Command]
    public void CmdChangeName (string newName)
    {
        pName = newName;
    }
}
