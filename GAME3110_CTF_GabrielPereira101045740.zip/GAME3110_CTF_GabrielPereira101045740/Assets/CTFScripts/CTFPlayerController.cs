﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CTFPlayerController : NetworkBehaviour {

    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    public float rotationSpeed = 150.0f;
    public float speed = 4.0f;

    private Rigidbody m_rb = null;
    private bool isSprinting = false;
    

    //public float m_movementForce = 3.0f;
    //public float m_sprintMultiplier = 2.5f;
    //public float m_angularSpeed = 3.0f;

    // Use this for initialization
    void Start ()
    {
        m_rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        //float forwardSpeed = Input.GetKey(KeyCode.W) ? GetMovementSpeed() : 0.0f;
        //float backwardSpeed = Input.GetKey(KeyCode.S) ? -GetMovementSpeed() : 0.0f;
        //float totalSpeed = forwardSpeed + backwardSpeed;

        //Vector3 horizontalVelocity = totalSpeed * transform.forward;

        //m_rb.AddForce(horizontalVelocity, ForceMode.Force);

        //float rightAngularSpeed = Input.GetKey(KeyCode.D) ? m_angularSpeed : 0.0f;
        //float leftAngularSpeed = Input.GetKey(KeyCode.A) ? -m_angularSpeed : 0.0f;
        //float totalAngularSpeed = rightAngularSpeed + leftAngularSpeed;
        //Vector3 angularVelocity = totalAngularSpeed * transform.up;
        //m_rb.angularVelocity = angularVelocity;

        var x = Input.GetAxis("Horizontal") * Time.deltaTime * rotationSpeed;
        var z = Input.GetAxis("Vertical") * Time.deltaTime * speed;

        transform.Rotate(0, x, 0);
        transform.Translate(0, 0, z);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            CmdFire();
        }
    }

    [Command]
    void CmdFire()
    {
        var bullet = (GameObject)Instantiate(bulletPrefab, bulletSpawn.position, bulletSpawn.rotation);
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * 6;
        NetworkServer.Spawn(bullet);
        Destroy(bullet, 6.0f);
    }

    //float GetMovementSpeed()
    //{
    //    return isSprinting ? m_movementForce * m_sprintMultiplier : m_movementForce;
    //}
}
