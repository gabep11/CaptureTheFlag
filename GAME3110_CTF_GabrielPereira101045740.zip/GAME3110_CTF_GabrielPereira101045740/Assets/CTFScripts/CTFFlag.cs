﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CTFFlag : NetworkBehaviour {

    public enum State
    {
        Available,
        Possessed
    };

    [SyncVar]
    State m_State;
    

	// Use this for initialization
	void Start () {
        m_State = State.Available;
	}
	
	// Update is called once per frame
	void Update () {
		if (m_State == State.Available)
        {
            this.transform.parent = null;
        }
        else if (m_State == State.Possessed)
        {

        }
	}

    public State GetState()
    {
        return m_State;
    }

    private void OnCollisionEnter(Collision collision)
    {
        //Debug.Log(isServer ? "Server" : "Not Server");
        
        if (isServer && m_State == State.Available && collision.gameObject.tag == "Player")
        {
            m_State = State.Possessed;
            RpcPickUpFlag(collision.gameObject);
        }
    }

    [ClientRpc]
    public void RpcPickUpFlag(GameObject player)
    {
        AttachFlagToGameObject(player);
    }

    void AttachFlagToGameObject(GameObject obj)
    {
        GetComponent<ParticleSystem>().Stop();
        CTFPlayerManager pm = obj.GetComponent<CTFPlayerManager>();
        if (pm)
        {
            this.GetComponent<CapsuleCollider>().enabled = false;
            this.transform.parent = pm.flagPlaceHolder;
            this.transform.localPosition = new Vector3(0, 0, 0);
            this.transform.localRotation = Quaternion.Euler(0, 0, 0);
            pm.CmdPickUpFlag();
        }
    }
}
